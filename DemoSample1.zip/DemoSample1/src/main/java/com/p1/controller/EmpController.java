package com.p1.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.p1.model.Emp;
import com.p1.service.EmpList;

@RestController
public class EmpController 
{
  ArrayList<Emp> elist1= new ArrayList<Emp>();	
  EmpList el1;
  EmpController()
  {   el1= new EmpList();
    }
  
  @RequestMapping("hi")
  public String sayHi()
  {
	  String message = " ";
	  message= "Welcome to DemoSample1 for JMeter";
	  return message;
  }
  
  @RequestMapping("displaylist")
  public ArrayList<Emp> displayElist()
  {
	  elist1= el1.createElist();
	  return elist1;
  }
	
  @RequestMapping("appendlist/{eobj1}")
  public ArrayList<Emp> appendEmp(Emp eobj1)
  {
	   elist1= el1.appendList(eobj1);
	   return elist1;
  }
	  
}