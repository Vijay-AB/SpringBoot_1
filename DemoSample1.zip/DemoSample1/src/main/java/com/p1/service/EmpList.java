
package com.p1.service;

import com.p1.model.Emp;
import java.util.ArrayList;

public class EmpList {

	ArrayList<Emp> elist;
	
	public EmpList()
	{
	   elist= new ArrayList<Emp>();	
	}
	
	public ArrayList<Emp> createElist()
	{
		elist.add(new Emp(10001, "Akash", 250000.00));
		elist.add(new Emp(10002, "Bhavana", 350000.00));
		elist.add(new Emp(10003, "Chitra", 300000.00));
		return elist;	
	}
	
	public ArrayList<Emp> appendList(Emp empobj)
	{
		elist.add(empobj);
		return elist;
	}
}
