package com.p1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSample1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
