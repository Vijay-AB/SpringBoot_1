package com.p1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	@GetMapping("/users")
	public String getAllUsers()
	{
		String message=" ";
		message = "Hi Users";
		System.out.println("All users from database got ");
		return message;
	}

}
