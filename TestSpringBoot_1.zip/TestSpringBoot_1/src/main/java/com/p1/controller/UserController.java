package com.p1.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.p1.model.User;

@RestController
public class UserController 
{
	@RequestMapping("/")
	public String hello() 
	{  return "Hello Spring Boot Enthusiasts @Susgaon ! ";
	  }
	
	@RequestMapping("/getAll")
	public ArrayList<User> getAllUsers()
	{
		ArrayList<User> user_list1= new ArrayList<User>();
		return user_list1;
	}
	
	@RequestMapping("/getUser/{u_id}")
	public User getUser()
	{
		User uobj= new User();
		return uobj;
	}
	
	@RequestMapping("/addUser/{uobj}")
	public void addUser(User uobj)
	{
		User uobja= uobj;
		
	}
	
	@RequestMapping("/delUser/{uobj}")
	public void delUser(User uobj)
	{
	   User uobjd= uobj;
		
	}
	
 }