package com.p1.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class User 
{

	int u_id;
	String u_name;
	char u_gen;
	double u_ctc;
	
	public User(int u_id, String u_name, char u_gen, double u_ctc) 
	{
	   this.u_id= u_id;
	   this.u_name= u_name;
	   this.u_gen= u_gen;
	   this.u_ctc= u_ctc;
		
	}
	

}
