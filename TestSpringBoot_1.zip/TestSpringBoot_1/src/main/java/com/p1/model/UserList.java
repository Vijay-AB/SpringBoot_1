package com.p1.model;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class UserList 
{
  ArrayList<User> userlist= new ArrayList<User>();
  
  public ArrayList<User> createUserList()
  {
    userlist.add(new User(1001, "Vijay", 'M', 2500000.00));
	  
	  return userlist;
  }
  
  
	
	
}
