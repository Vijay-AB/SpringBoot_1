package com.p1.service;

import java.util.ArrayList;
import org.springframework.stereotype.Service;

import com.p1.model.User;

@Service
public class UserService 
{
public ArrayList<User> getUsers()
{
	ArrayList<User> ul1= ((Object) ul1).createUserList();
	
	return ul1;
}


	
	
}
