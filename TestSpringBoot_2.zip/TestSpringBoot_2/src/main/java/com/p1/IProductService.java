package com.p1;

import java.util.List;

public interface IProductService 
   {	
	 public List<Product> findAll();  
	}  