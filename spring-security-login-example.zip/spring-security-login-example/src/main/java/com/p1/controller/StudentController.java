package com.p1.controller;
import com.p1.model.Student;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController 
{
	private List<Student> students = new ArrayList();
     @GetMapping("/students") 
	 public List<Student> students()
	 {
		students.add(new Student(1001, "Amitabh","Bachan"));
		students.add(new Student(1002, "Rishab","Shetty"));	
		return students;
	 }
	 
     
	 public Student createStudent(Student st)
	 {
		 students.add(st);
		 return st;
	 }
	 
	 
	 
}
