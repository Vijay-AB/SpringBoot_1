package com.p1;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class UserServiceAspect {
	@Before(value="execution(* com.p1..*(..))')")
	public void beforeAdvice(JoinPoint jp1)
	{
		System.out.println("Before UserServiceAspect ###");
	}
	
	@After (value="execution(* com.p1..*(..))')")
	public void afterAdvice(JoinPoint jp1)
	{
		System.out.println("After UserServiceAspect ###");
	}
	
	@AfterReturning(value="execution(* com.p1..*(..))')")
	public void afterReturn(JoinPoint jp1)
	{
		System.out.println("AfterReturning UserServiceAspect ###");
	}
	
	@Around(value="execution(* com.p1..*(..))')")
	public void aroundAdvice(ProceedingJoinPoint jp1)
	{
		System.out.println("Around UserServiceAspect ###");
		try
		{
			jp1.proceed();
		}catch(Throwable th1)
		{
			System.out.println("Exception occured");
		}
	}
}
